package ex01;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Exam {
	List<Integer> i_arr =  Arrays.asList(1,1,1,2,2,2,2,3,3,3,4,4,4,4,4,5,5,5,5,5);
	int num ;
	
	public void removeDuplicates(List<Integer> i_arr) {
		this.i_arr = i_arr;
	}

	
	public void sumOfDigits(int num) {
		this.num = num;
	}


}
